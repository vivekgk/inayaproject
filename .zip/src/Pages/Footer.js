import React from 'react';

const Footer = () => {
    return (
        <div>
             <footer className="w3l-footer9">
    <section className="footer-inner-main py-5">
      <div className="container py-md-4">
        <div className="right-side">
          <div className="row footer-hny-grids sub-columns">
            <div className="col-lg-3 sub-one-left">
              <h6>About </h6>
              <p className="footer-phny pe-lg-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ute dolor sit.</p>
              <div className="columns-2 mt-4 pt-lg-2">
                <ul className="social">
                  <li><a href="#facebook"><span className="fab fa-facebook-f" /></a>
                  </li>
                  <li><a href="#linkedin"><span className="fab fa-linkedin-in" /></a>
                  </li>
                  <li><a href="#twitter"><span className="fab fa-twitter" /></a>
                  </li>
                  <li><a href="#google"><span className="fab fa-google-plus-g" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Company</h6>
              <ul>
                <li><a href="#why"><i className="fas fa-angle-right" /> Why Us</a>
                </li>
                <li><a href="#licence"><i className="fas fa-angle-right" />Our Agents
                  </a>
                </li>
                <li><a href="#log"><i className="fas fa-angle-right" />Our Offers
                  </a></li>
                <li><a href="#career"><i className="fas fa-angle-right" /> Careers</a></li>
              </ul>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Services</h6>
              <ul>
                <li><a href="#processing"><i className="fas fa-angle-right" /> Buy Properties</a>
                </li>
                <li><a href="#research"><i className="fas fa-angle-right" /> Sell Properties</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Rent Properties</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Property Search</a>
                </li>
              </ul>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Explore</h6>
              <ul>
                <li><a href="#processing"><i className="fas fa-angle-right" /> Homes for Rent</a>
                </li>
                <li><a href="#research"><i className="fas fa-angle-right" /> Apartments for Rent</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Homes for Sale</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Apartments for Sale</a>
                </li>
              </ul>
            </div>
            <div className="col-lg-3 sub-one-left ps-lg-5">
              <h6>Stay Update!</h6>
              <p className="w3f-para mb-4">Subscribe to our newsletter to receive our weekly feed.</p>
              <div className="w3l-subscribe-content align-self mt-lg-0 mt-5">
                <form action="#" method="post" className="subscribe-wthree">
                  <div className="flex-wrap subscribe-wthree-field">
                    <input className="form-control" type="email" placeholder="Email" name="email" required />
                    <button className="btn btn-style btn-primary" type="submit">Subscribe</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="below-section mt-5 pt-lg-3">
          <div className="copyright-footer">
            <ul className="footer-w3list text-right">
              <li><a href="#url">Privacy Policy</a>
              </li>
              <li><a href="#url">Terms &amp; Conditions</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <button onclick="topFunction()" id="movetop" title="Go to top">
      <span className="fas fa-level-up-alt" aria-hidden="true" />
    </button>
  </footer>
        </div>
    );
}

export default Footer;
