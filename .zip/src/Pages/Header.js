import React from 'react';
import {Link} from "react-router-dom"
const Header = () => {
    return (
        <React.Fragment>
             <header id="site-header" className="fixed-top">
    <div className="container">
      <nav className="navbar navbar-expand-lg navbar-light stroke py-lg-0">
        <h1><a className="navbar-brand" href="index.html">
            Real<span className="sub-color">Houzing</span>
          </a></h1>
        <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon fa icon-expand fa-bars" />
          <span className="navbar-toggler-icon fa icon-close fa-times" />
        </button>
        <div className="collapse navbar-collapse" id="navbarScroll">
          <ul className="navbar-nav mx-lg-auto my-2 my-lg-0 navbar-nav-scroll">
            <li className="nav-item">
            <Link to="/"  className="nav-link">Home</Link>
            </li>
            <li className="nav-item">
              <Link to="/about" className="nav-link">About</Link>
            </li>
            <li className="nav-item">
              <Link to="/service" className="nav-link">Services</Link>
            </li>
            <li className="nav-item">
              <Link to="/contact" className="nav-link">Contact</Link>
            </li>
          </ul>
          <button id="trigger-overlay" className="searchw3-icon me-xl-4 me-lg-3" type="button"><i className="fas fa-search" /></button>
          <div className="overlay overlay-slidedown">
            <button type="button" className="overlay-close"><i className="fas fa-times" /></button>
            <nav className="w3l-formhny">
              <h5 className="mb-3">Search here</h5>
              <form action="#" method="GET" className="d-sm-flex search-header">
                <input className="form-control me-2" type="search" placeholder="Search here..." aria-label="Search" required />
                <button className="btn btn-style btn-primary" type="submit">Search</button>
              </form>
            </nav>
          </div>
        </div>
        <div className="mobile-position">
          <nav className="navigation">
            <div className="theme-switch-wrapper">
              <label className="theme-switch" htmlFor="checkbox">
                <input type="checkbox" id="checkbox" />
                <div className="mode-container">
                  <i className="gg-sun" />
                  <i className="gg-moon" />
                </div>
              </label>
            </div>
          </nav>
        </div>
      </nav>
    </div>
  </header>
        </React.Fragment>
    );
}

export default Header;
