import React from 'react';
import { Link } from "react-router-dom"

const Service = () => {
    return (
        <React.Fragment>

            <div className="inner-banner py-5">
                <section className="w3l-breadcrumb text-left py-sm-5 ">
                    <div className="container">
                        <div className="w3breadcrumb-gids">
                            <div className="w3breadcrumb-left text-left">
                                <h2 className="inner-w3-title mt-sm-5 mt-4">
                                    Services </h2>
                            </div>
                            <div className="w3breadcrumb-right">
                                <ul className="breadcrumbs-custom-path">
                                    <li> <Link to="/">Home</Link></li>
                                    <li className="active"><span className="fas fa-angle-double-right mx-2" /> Services </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <section className="w3l-passion-mid-sec py-5 pb-0">
                <div className="container py-md-5 py-3 pb-0">
                    <div className="container">
                        <div className="row w3l-passion-mid-grids">
                            <div className="col-lg-6 passion-grid-item-info pe-lg-5 mb-lg-0 mb-5">
                                <h6 className="title-subw3hny mb-1">Post Your Property</h6>
                                <h3 className="title-w3l mb-4">Property owners get free posting when they register</h3>
                                <p className="mt-3 pe-lg-5">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in
                                    ligula. Semper at tempufddfel.Lorem ipsum dolor sit, amet consectetur elit. Earum mollitia
                                    cum ex ipsam autem!earum sequi amet.</p>
                                <div className="w3banner-content-btns">
                                    <a href="about.html" className="btn btn-style btn-primary mt-lg-5 mt-4 me-2">Services <i className="fas fa-angle-double-right ms-2" /></a>
                                    <a href="contact.html" className="btn btn-style btn-outline-dark mt-lg-5 mt-4">Contact Us <i className="fas fa-angle-double-right ms-2" /></a>
                                </div>
                            </div>
                            <div className="col-lg-6 passion-grid-item-info">
                                <img src="assets/images/g6.jpg" alt className="img-fluid radius-image" />
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section className="locations-1 w3services-3">
                <div className="locations py-5">
                    <div className="container py-lg-5 py-md-4 py-2">
                        <div className="heading text-center mx-auto">
                            <h6 className="title-subw3hny mb-1">Our Properties</h6>
                            <h3 className="title-w3l mb-3">Explore Our Properties</h3>
                        </div>
                        <div className="row">
                            <div className="col-lg-3 col-6 mt-md-5 mt-4">
                                <div className="w3property-grid">
                                    <a href="#property">
                                        <div className="box16">
                                            <img className="img-fluid" src="assets/images/d1.jpg" alt />
                                            <div className="box-content text-center">
                                                <i className="fas fa-home" />
                                                <h3 className="title">House</h3>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div className="col-lg-3 col-6 mt-md-5 mt-4">
                                <div className="w3property-grid">
                                    <a href="#property">
                                        <div className="box16">
                                            <img className="img-fluid" src="assets/images/d2.jpg" alt />
                                            <div className="box-content text-center">
                                                <i className="far fa-building" />
                                                <h3 className="title">Appartment</h3>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div className="col-lg-3 col-6 mt-md-5 mt-4">
                                <div className="w3property-grid">
                                    <a href="#property">
                                        <div className="box16">
                                            <img className="img-fluid" src="assets/images/d3.jpg" alt />
                                            <div className="box-content text-center">
                                                <i className="fas fa-house-damage" />
                                                <h3 className="title">Villa</h3>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div className="col-lg-3 col-6 mt-md-5 mt-4">
                                <div className="w3property-grid">
                                    <a href="#property">
                                        <div className="box16">
                                            <img className="img-fluid" src="assets/images/d4.jpg" alt />
                                            <div className="box-content text-center">
                                                <i className="fas fa-hotel" />
                                                <h3 className="title">Town</h3>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section className="w3l-features py-5" id="work">
                <div className="container py-lg-5 py-md-4 py-2">
                    <div className="title-content text-center mb-lg-3 mb-4">
                        <h6 className="title-subw3hny mb-1">What We Do</h6>
                        <h3 className="title-w3l">What We Offered</h3>
                    </div>
                    <div className="main-cont-wthree-2">
                        <div className="row">
                            <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
                                <div className="grids-1 box-wrap">
                                    <div className="icon">
                                        <i className="fas fa-thumbs-up" />
                                    </div>
                                    <h4><a href="#service" className="title-head mb-3">Guidance you need</a></h4>
                                    <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
                                <div className="grids-1 box-wrap">
                                    <div className="icon">
                                        <i className="fas fa-search-plus" />
                                    </div>
                                    <h4><a href="#service" className="title-head mb-3">Search that feels familiar</a></h4>
                                    <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
                                <div className="grids-1 box-wrap">
                                    <div className="icon">
                                        <i className="fas fa-tags" />
                                    </div>
                                    <h4><a href="#service" className="title-head mb-3">Premium values</a></h4>
                                    <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
                                <div className="grids-1 box-wrap">
                                    <div className="icon">
                                        <i className="fas fa-shield-alt" />
                                    </div>
                                    <h4><a href="#service" className="title-head mb-3">Secure Payment</a></h4>
                                    <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
                                <div className="grids-1 box-wrap">
                                    <div className="icon">
                                        <i className="far fa-money-bill-alt" />
                                    </div>
                                    <h4><a href="#service" className="title-head mb-3">No Commission</a></h4>
                                    <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
                                <div className="grids-1 box-wrap">
                                    <div className="icon">
                                        <i className="fas fa-users" />
                                    </div>
                                    <h4><a href="#service" className="title-head mb-3">Top Rated Agents</a></h4>
                                    <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section className="w3l-pricing-sec py-5" id="pricing">
                <div className="container py-md-5 py-2">
                    <div className="heading text-center mx-auto">
                        <h6 className="title-subw3hny mb-1">Our Plans</h6>
                        <h3 className="title-w3l mb-2">Our Plans</h3>
                    </div>
                    <div className="row pricing-main-grids">
                        <div className="col-lg-4 col-md-6 pricing-main-grid mt-sm-5 mt-4">
                            <div className="w3-pricing-inner-inf">
                                <div className="pricing-header text-center">
                                    <div className="price-icon">
                                        <i className="fas fa-home mt-0" />
                                    </div>
                                    <h4>Personal</h4>
                                    <p className="pb-3">Free/month</p>
                                </div>
                                <div className="pricing-body pt-3 text-center">
                                    <p>10 Listings <br />2 Featured Listings</p>
                                    <div className="pricing-get-button mb-2">
                                        <a href="contact.html" className="btn btn-style btn-primary d-block mt-4">
                                            Choose Plan <span className="fas fa-angle-double-right ms-2" /></a>
                                    </div>
                                    <p className="subtitle">10% money back guarantee</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 pricing-main-grid mt-sm-5 mt-4">
                            <div className="w3-pricing-inner-inf active">
                                <div className="pricing-header text-center">
                                    <div className="price-icon">
                                        <i className="far fa-building mt-0" />
                                    </div>
                                    <h4>Professional</h4>
                                    <p className="pb-3">49.99/6 month</p>
                                </div>
                                <div className="pricing-body pt-3 text-center">
                                    <p>20 Listings <br />5 Featured Listings</p>
                                    <div className="pricing-get-button mb-2">
                                        <a href="contact.html" className="btn btn-style btn-primary d-block mt-4">
                                            Choose Plan <span className="fas fa-angle-double-right ms-2" /></a>
                                    </div>
                                    <p className="subtitle">20% money back guarantee</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 pricing-main-grid mt-sm-5 mt-4">
                            <div className="w3-pricing-inner-inf">
                                <div className="pricing-header text-center">
                                    <div className="price-icon">
                                        <i className="fas fa-building mt-0" />
                                    </div>
                                    <h4>Business</h4>
                                    <p className="pb-3">99.99/1 Year</p>
                                </div>
                                <div className="pricing-body pt-3 text-center">
                                    <p>30 Listings <br />10 Featured Listings</p>
                                    <div className="pricing-get-button mb-2">
                                        <a href="contact.html" className="btn btn-style btn-primary d-block mt-4">
                                            Choose Plan <span className="fas fa-angle-double-right ms-2" /> </a>
                                    </div>
                                    <p className="subtitle">10% money back guarantee</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* //w3l-pricing*/}
            {/*/footer-9*/}
            {/* <footer className="w3l-footer9">
    <section className="footer-inner-main py-5">
      <div className="container py-md-4">
        <div className="right-side">
          <div className="row footer-hny-grids sub-columns">
            <div className="col-lg-3 sub-one-left">
              <h6>About </h6>
              <p className="footer-phny pe-lg-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ute dolor sit.</p>
              <div className="columns-2 mt-4 pt-lg-2">
                <ul className="social">
                  <li><a href="#facebook"><span className="fab fa-facebook-f" /></a>
                  </li>
                  <li><a href="#linkedin"><span className="fab fa-linkedin-in" /></a>
                  </li>
                  <li><a href="#twitter"><span className="fab fa-twitter" /></a>
                  </li>
                  <li><a href="#google"><span className="fab fa-google-plus-g" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Company</h6>
              <ul>
                <li><a href="#why"><i className="fas fa-angle-right" /> Why Us</a>
                </li>
                <li><a href="#licence"><i className="fas fa-angle-right" />Our Agents
                  </a>
                </li>
                <li><a href="#log"><i className="fas fa-angle-right" />Our Offers
                  </a></li>
                <li><a href="#career"><i className="fas fa-angle-right" /> Careers</a></li>
              </ul>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Services</h6>
              <ul>
                <li><a href="#processing"><i className="fas fa-angle-right" /> Buy Properties</a>
                </li>
                <li><a href="#research"><i className="fas fa-angle-right" /> Sell Properties</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Rent Properties</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Property Search</a>
                </li>
              </ul>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Explore</h6>
              <ul>
                <li><a href="#processing"><i className="fas fa-angle-right" /> Homes for Rent</a>
                </li>
                <li><a href="#research"><i className="fas fa-angle-right" /> Apartments for Rent</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Homes for Sale</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Apartments for Sale</a>
                </li>
              </ul>
            </div>
            <div className="col-lg-3 sub-one-left ps-lg-5">
              <h6>Stay Update!</h6>
              <p className="w3f-para mb-4">Subscribe to our newsletter to receive our weekly feed.</p>
              <div className="w3l-subscribe-content align-self mt-lg-0 mt-5">
                <form action="#" method="post" className="subscribe-wthree">
                  <div className="flex-wrap subscribe-wthree-field">
                    <input className="form-control" type="email" placeholder="Email" name="email" required />
                    <button className="btn btn-style btn-primary" type="submit">Subscribe</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="below-section mt-5 pt-lg-3">
          <div className="copyright-footer">
            <div className="columns text-left">
              <p>© 2021 RealHouzing.All rights reserved. Design by <a href="https://w3layouts.com/" target="_blank">
                  W3Layouts</a></p>
            </div>
            <ul className="footer-w3list text-right">
              <li><a href="#url">Privacy Policy</a>
              </li>
              <li><a href="#url">Terms &amp; Conditions</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <button onclick="topFunction()" id="movetop" title="Go to top">
      <span className="fas fa-level-up-alt" aria-hidden="true" />
    </button>
  </footer> */}


        </React.Fragment>
    );
}

export default Service;
