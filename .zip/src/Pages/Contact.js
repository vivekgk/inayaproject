import React from 'react';
import { Link } from "react-router-dom"

const Contact = () => {
    return (
       <React.Fragment>
  <div className="inner-banner py-5">
    <section className="w3l-breadcrumb text-left py-sm-5 ">
      <div className="container">
        <div className="w3breadcrumb-gids">
          <div className="w3breadcrumb-left text-left">
            <h2 className="inner-w3-title mt-sm-5 mt-4">
              Contact Us </h2>
          </div>
          <div className="w3breadcrumb-right">
            <ul className="breadcrumbs-custom-path">
            <li> <Link to="/">Home</Link></li>
              <li className="active"><span className="fas fa-angle-double-right mx-2" /> Contact</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </div>
  <div className="w3l-contact-10 py-5" id="contact">
    <div className="form-41-mian pt-lg-4 pt-md-3 pb-lg-4">
      <div className="container">
        <div className="heading text-center mx-auto">
          <h5 className="title-subw3hny text-center">Contact our team</h5>
          <h3 className="title-w3l">Got any <span className="inn-text">Questions? </span></h3>
        </div>
        <div className="contacts-5-grid-main mt-5">
          <div className="contacts-5-grid">
            <div className="map-content-5">
              <div className="d-grid grid-col-2 justify-content-center">
                <div className="contact-type">
                  <div className="address-grid">
                    <span className="fas fa-map-marked-alt" />
                    <h6>Address</h6>
                    <p>#302, 5th Floor, VHLY-2247 ek,RealHouzing, New York.</p>
                  </div>
                  <div className="address-grid">
                    <span className="fas fa-envelope-open-text" />
                    <h6>Email</h6>
                    <a href="mailto:mailone@example.com" className="link1">mailone@example.com</a>
                    <a href="mailto:mailtwo@example.com" className="link1">mailtwo@example.com</a>
                  </div>
                  <div className="address-grid">
                    <span className="fas fa-phone-alt" />
                    <h6>Phone</h6>
                    <a href="tel:+12 324-016-695" className="link1">+12 324-016-695</a>
                    <a href="tel:+44 224-058-545" className="link1">+44 224-058-545</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="form-inner-cont mt-5">
          <form action="https://sendmail.w3layouts.com/submitForm" method="post" className="signin-form">
            <div className="form-grids">
              <div className="form-input">
                <input type="text" name="w3lName" id="w3lName" placeholder="Enter your name *" required />
              </div>
              <div className="form-input">
                <input type="text" name="w3lSubject" id="w3lSubject" placeholder="Enter subject " required />
              </div>
              <div className="form-input">
                <input type="email" name="w3lSender" id="w3lSender" placeholder="Enter your email *" required />
              </div>
              <div className="form-input">
                <input type="text" name="w3lPhone" id="w3lPhone" placeholder="Enter your Phone Number *" required />
              </div>
            </div>
            <div className="form-input">
              <textarea name="w3lMessage" id="w3lMessage" placeholder="Type your query here" required defaultValue={""} />
            </div>
            <div className="w3-submit text-right">
              <button className="btn btn-style btn-primary">Send Message <i className="fas fa-paper-plane ms-2" /></button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div className="contacts-sub-5">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.305935303!2d-74.25986548248684!3d40.69714941932609!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sin!4v1563262564932!5m2!1sen!2sin" style={{border: 0}} allowFullScreen />
  </div>
</React.Fragment>

    );
}

export default Contact;
