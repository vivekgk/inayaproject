import React from 'react';

const Home = () => {
    return (
            <React.Fragment>
  <section className="w3l-main-slider banner-slider" id="home">
    <div className="owl-one owl-carousel owl-theme">
      <div className="item">
        <div className="slider-info banner-view banner-top1">
          <div className="container">
            <div className="banner-info header-hero-19">
              <p className="w3hny-tag">Real Estate is our life</p>
              <h3 className="title-hero-19">The creativity of the new world.</h3>
              <a href="about.html" className="btn btn-style btn-primary mt-4">Read More <i className="fas fa-angle-double-right ms-2" /></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section className="w3l-witemshny-main py-5">
    <div className="container py-md-4">
      <div className="witemshny-grids row">
        <div className="col-xl-2 col-md-4 col-6 product-incfhny mt-4">
          <div className="weitemshny-grid oposition-relative">
            <a href="#img" className="d-block zoom"><img src="assets/images/d1.jpg" alt className="img-fluid news-image" /></a>
            <div className="witemshny-inf">
            </div>
          </div>
          <h4 className="gdnhy-1 mt-4"><a href="#img">Buying a Home</a>
          </h4>
        </div>
        <div className="col-xl-2 col-md-4 col-6 product-incfhny mt-4">
          <div className="weitemshny-grid oposition-relative">
            <a href="#img" className="d-block zoom"><img src="assets/images/d2.jpg" alt className="img-fluid news-image" /></a>
            <div className="witemshny-inf">
            </div>
          </div>
          <h4 className="gdnhy-1 mt-4"><a href="#img">Renting a Home</a>
          </h4>
        </div>
        <div className="col-xl-2 col-md-4 col-6 product-incfhny mt-4">
          <div className="weitemshny-grid oposition-relative">
            <a href="#img" className="d-block zoom"><img src="assets/images/d3.jpg" alt className="img-fluid news-image" /></a>
            <div className="witemshny-inf">
            </div>
          </div>
          <h4 className="gdnhy-1 mt-4"><a href="#img">Sell Your Property</a>
          </h4>
        </div>
        <div className="col-xl-2 col-md-4 col-6 product-incfhny mt-4">
          <div className="weitemshny-grid oposition-relative">
            <a href="#img" className="d-block zoom"><img src="assets/images/d4.jpg" alt className="img-fluid news-image" /></a>
            <div className="witemshny-inf">
            </div>
          </div>
          <h4 className="gdnhy-1 mt-4"><a href="#img">PG and Co Living</a>
          </h4>
        </div>
        <div className="col-xl-2 col-md-4 col-6 product-incfhny mt-4">
          <div className="weitemshny-grid oposition-relative">
            <a href="#img" className="d-block zoom"><img src="assets/images/d5.jpg" alt className="img-fluid news-image" /></a>
            <div className="witemshny-inf">
            </div>
          </div>
          <h4 className="gdnhy-1 mt-4"><a href="#img">Buying Spaces</a>
          </h4>
        </div>
        <div className="col-xl-2 col-md-4 col-6 product-incfhny mt-4">
          <div className="weitemshny-grid oposition-relative">
            <a href="#img" className="d-block zoom"><img src="assets/images/d6.jpg" alt className="img-fluid news-image" /></a>
            <div className="witemshny-inf">
            </div>
          </div>
          <h4 className="gdnhy-1 mt-4"><a href="#img">Living Spaces</a>
          </h4>
        </div>
      </div>
      {/*//row-1*/}
    </div>
  </section>
  <div className=" w3l-3-grids py-5" id="grids-3">
    <div className="container py-md-4">
      <div className="row">
        <div className="col-md-6 mt-md-0">
          <div className="grids3-info position-relative">
            <a href="#img" className="d-block zoom"><img src="assets/images/banner1.jpg" alt className="img-fluid news-image" /></a>
            <div className="w3-grids3-info">
              <h4 className="gdnhy-1"><a href="#img">Buy a Commercial<br />Property</a>
                <a className="w3item-link btn btn-style mt-4" href="#">
                  Explore Property <i className="fas fa-angle-double-right ms-2" />
                </a>
              </h4>
            </div>
          </div>
        </div>
        <div className="col-md-6 mt-md-0 mt-4 grids3-info2">
          <div className="grids3-info position-relative">
            <a href="#img" className="d-block zoom"><img src="assets/images/banner2.jpg" alt className="img-fluid news-image" /></a>
            <div className="w3-grids3-info second">
              <h4 className="gdnhy-1"><a href="#img">Lease a Commercial<br />Property</a>
                <a className="w3item-link btn btn-style mt-4" href="#">
                  Explore Property <i className="fas fa-angle-double-right ms-2" />
                </a>
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <section className="w3l-grids-3 py-5" id="about">
    <div className="container py-md-5 py-3">
      <div className="row bottom-ab-grids">
        <div className="w3l-video-left col-lg-6" id="video">
          <div className="w3l-index5">
            <div className="position-relative mt-4">
              <a href="#small-dialog" className="popup-with-zoom-anim play-view text-center position-absolute">
                <span className="video-play-icon">
                  <span className="fa fa-play" />
                </span>
              </a>
              <div id="small-dialog" className="zoom-anim-dialog mfp-hide">
                <iframe src="https://player.vimeo.com/video/23512331" frameBorder={0} allow="autoplay; fullscreen" allowFullScreen />
              </div>
            </div>
          </div>
        </div>
        <div className="w3ab-left-top col-lg-6 mt-lg-0 mt-5 ps-lg-5">
          <h6 className="title-subw3hny mb-1">Buy a Home</h6>
          <h3 className="title-w3l mb-2">Find, Buy &amp; Own Your Dream Home</h3>
          <p className="my-3"> Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. Semper at tempufddfel.Lorem ipsum dolor sit, amet consectetur ante ipsum elit. </p>
          <p className="my-3"> Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;
            Nulla mollis dapibus nunc.</p>
          <a href="about.html" className="btn btn-style btn-primary mt-4">Explore Buying <i className="fas fa-angle-double-right ms-2" /></a>
        </div>
      </div>
    </div>
  </section>
  <section className="w3l-passion-mid-sec py-5 pt-0">
    <div className="container py-md-5 py-3 pt-0">
      <div className="container">
        <div className="row w3l-passion-mid-grids">
          <div className="col-lg-6 passion-grid-item-info pe-lg-5 mb-lg-0 mb-5">
            <h6 className="title-subw3hny mb-1">Post Your Property</h6>
            <h3 className="title-w3l mb-4">Property owners get free posting when they register</h3>
            <p className="mt-3 pe-lg-5">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in
              ligula. Semper at tempufddfel.Lorem ipsum dolor sit, amet consectetur elit. Earum mollitia
              cum ex ipsam autem!earum sequi amet.</p>
            <div className="w3banner-content-btns">
              <a href="about.html" className="btn btn-style btn-primary mt-lg-5 mt-4 me-2">Property For Free <i className="fas fa-angle-double-right ms-2" /></a>
            </div>
          </div>
          <div className="col-lg-6 passion-grid-item-info">
            <img src="assets/images/g6.jpg" alt className="img-fluid radius-image" />
          </div>
        </div>
      </div>
    </div>
  </section>
  <section className="w3l-features py-5" id="features">
    <div className="container py-lg-5 py-md-4 py-2">
      <div className="title-content text-center mb-lg-3 mb-4">
        <h6 className="title-subw3hny mb-1">What We Do</h6>
        <h3 className="title-w3l">We're on a Mission to Change
          View of RealEstate Field.</h3>
      </div>
      <div className="main-cont-wthree-2">
        <div className="row justify-content-center">
          <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
            <div className="grids-1 box-wrap">
              <div className="icon">
                <i className="fas fa-pen-fancy" />
              </div>
              <h4><a href="#service" className="title-head mb-3">Your One-Stop Shop for Finding Your Dream Home</a></h4>
              <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
            <div className="grids-1 box-wrap">
              <div className="icon">
                <i className="fas fa-layer-group" />
              </div>
              <h4><a href="#service" className="title-head mb-3">Schedule a Free, No-Obligation Appointment</a></h4>
              <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-lg-5 mt-4">
            <div className="grids-1 box-wrap">
              <div className="icon">
                <i className="fas fa-house-user" />
              </div>
              <h4><a href="#service" className="title-head mb-3">Understand the Value of Your Property</a></h4>
              <p className="text-para">Lorem ipsum dolor sit amet, elit. Id ab commodi magnam. </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section className="locations-1" id="locations">
    <div className="locations py-5">
      <div className="container py-lg-5 py-md-4 py-2">
        <div className="heading text-center mx-auto">
          <h6 className="title-subw3hny mb-1">Our Properties</h6>
          <h3 className="title-w3l mb-3">Latest Properties</h3>
        </div>
        <div className="row pt-md-5 pt-4">
          <div className="col-lg-4 col-md-6">
            <div className="w3property-grid">
              <a href="#property">
                <div className="box16">
                  <div className="rentext-listing-category"><span className="pro-left">Buy</span><span className="pro-right">Rent</span></div>
                  <img className="img-fluid" src="assets/images/g1.jpg" alt />
                  <div className="box-content">
                    <h3 className="title">$25,00,000</h3>
                    <span className="post">51 Merrick Way, Coral Gables, USA</span>
                  </div>
                </div>
              </a>
              <div className="list-information space-between">
                <ul className="product-features">
                  <li>
                    <i className="fas fa-bed" />
                    <span className="listable-value">
                      <span className="prefix">
                        Beds </span>
                      <span className="value">
                        <span>0</span>4 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-shower" />
                    <span className="listable-value">
                      <span className="prefix">
                        Baths </span>
                      <span className="value">
                        <span>0</span>2 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-vector-square" />
                    <span className="listable-value">
                      <span className="prefix">
                      </span>
                      <span className="value">
                        1200 </span>
                      <span className="suffix">
                        Sqft </span>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-md-0 mt-4">
            <div className="w3property-grid">
              <a href="#property">
                <div className="box16">
                  <div className="rentext-listing-category"><span>Buy</span><span>Rent</span></div>
                  <img className="img-fluid" src="assets/images/g2.jpg" alt />
                  <div className="box-content">
                    <h3 className="title">$37,00,000</h3>
                    <span className="post">51 Merrick Way, Coral Gables, USA</span>
                  </div>
                </div>
              </a>
              <div className="list-information space-between">
                <ul className="product-features">
                  <li>
                    <i className="fas fa-bed" />
                    <span className="listable-value">
                      <span className="prefix">
                        Beds </span>
                      <span className="value">
                        <span>0</span>2 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-shower" />
                    <span className="listable-value">
                      <span className="prefix">
                        Baths </span>
                      <span className="value">
                        <span>0</span>2 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-vector-square" />
                    <span className="listable-value">
                      <span className="prefix">
                      </span>
                      <span className="value">
                        1000 </span>
                      <span className="suffix">
                        Sqft </span>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-lg-0 pt-lg-0 mt-4 pt-md-2">
            <div className="w3property-grid">
              <a href="#property">
                <div className="box16">
                  <div className="rentext-listing-category"><span>Buy</span><span>Rent</span></div>
                  <img className="img-fluid" src="assets/images/g3.jpg" alt />
                  <div className="box-content">
                    <h3 className="title">$41,00,000</h3>
                    <span className="post">51 Merrick Way, Coral Gables, USA</span>
                  </div>
                </div>
              </a>
              <div className="list-information space-between">
                <ul className="product-features">
                  <li>
                    <i className="fas fa-bed" />
                    <span className="listable-value">
                      <span className="prefix">
                        Beds </span>
                      <span className="value">
                        <span>0</span>3 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-shower" />
                    <span className="listable-value">
                      <span className="prefix">
                        Baths </span>
                      <span className="value">
                        <span>0</span>2 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-vector-square" />
                    <span className="listable-value">
                      <span className="prefix">
                      </span>
                      <span className="value">
                        1400 </span>
                      <span className="suffix">
                        Sqft </span>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-4 pt-md-2">
            <div className="w3property-grid">
              <a href="#property">
                <div className="box16">
                  <div className="rentext-listing-category"><span>Buy</span><span>Rent</span></div>
                  <img className="img-fluid" src="assets/images/g4.jpg" alt />
                  <div className="box-content">
                    <h3 className="title">$19,00,000</h3>
                    <span className="post">51 Merrick Way, Coral Gables, USA</span>
                  </div>
                </div>
              </a>
              <div className="list-information space-between">
                <ul className="product-features">
                  <li>
                    <i className="fas fa-bed" />
                    <span className="listable-value">
                      <span className="prefix">
                        Beds </span>
                      <span className="value">
                        <span>0</span>2 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-shower" />
                    <span className="listable-value">
                      <span className="prefix">
                        Baths </span>
                      <span className="value">
                        <span>0</span>2 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-vector-square" />
                    <span className="listable-value">
                      <span className="prefix">
                      </span>
                      <span className="value">
                        1200 </span>
                      <span className="suffix">
                        Sqft </span>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-4 pt-md-2">
            <div className="w3property-grid">
              <a href="#property">
                <div className="box16">
                  <div className="rentext-listing-category"><span>Buy</span><span>Rent</span></div>
                  <img className="img-fluid" src="assets/images/g5.jpg" alt />
                  <div className="box-content">
                    <h3 className="title">$26,00,000</h3>
                    <span className="post">51 Merrick Way, Coral Gables, USA</span>
                  </div>
                </div>
              </a>
              <div className="list-information space-between">
                <ul className="product-features">
                  <li>
                    <i className="fas fa-bed" />
                    <span className="listable-value">
                      <span className="prefix">
                        Beds </span>
                      <span className="value">
                        <span>0</span>3 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-shower" />
                    <span className="listable-value">
                      <span className="prefix">
                        Baths </span>
                      <span className="value">
                        <span>0</span>2 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-vector-square" />
                    <span className="listable-value">
                      <span className="prefix">
                      </span>
                      <span className="value">
                        1400 </span>
                      <span className="suffix">
                        Sqft </span>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-4 pt-md-2">
            <div className="w3property-grid">
              <a href="#property">
                <div className="box16">
                  <div className="rentext-listing-category"><span>Buy</span><span>Rent</span></div>
                  <img className="img-fluid" src="assets/images/g6.jpg" alt />
                  <div className="box-content">
                    <h3 className="title">$34,00,000</h3>
                    <span className="post">51 Merrick Way, Coral Gables, USA</span>
                  </div>
                </div>
              </a>
              <div className="list-information space-between">
                <ul className="product-features">
                  <li>
                    <i className="fas fa-bed" />
                    <span className="listable-value">
                      <span className="prefix">
                        Beds </span>
                      <span className="value">
                        <span>0</span>3 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-shower" />
                    <span className="listable-value">
                      <span className="prefix">
                        Baths </span>
                      <span className="value">
                        <span>0</span>1 </span>
                      <span className="suffix">
                      </span>
                    </span>
                  </li>
                  <li>
                    <i className="fas fa-vector-square" />
                    <span className="listable-value">
                      <span className="prefix">
                      </span>
                      <span className="value">
                        1200 </span>
                      <span className="suffix">
                        Sqft </span>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section className="w3l-join-main py-5">
    <div className="container py-md-5">
      <div className="w3l-project-in">
        <div className="bottom-info text-center pb-lg-5">
          <div className="header-section pe-lg-5">
            <h6 className="title-subw3hny mb-2">Join With Us</h6>
            <h3 className="title-w3l two mb-2">Become a Real Estate Agent
            </h3>
            <p className="mb-2">We only work with the best companies around the globe</p>
            <div className="w3banner-content-btns pb-5 pb-5">
              <a href="about.html" className="btn btn-style btn-primary mt-4">Read More <i className="fas fa-angle-double-right ms-2" /></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section className="w3l-testimonials-main" id="testimonials">
    <div className="container">
      <div className="w3l-clients">
        <div id="owl-demo1" className="owl-carousel owl-theme">
          <div className="item">
            <div className="row no-gutters m-lg-0 test-w3hny-info">
              <div className="col-lg-5 w3l-left-img1">
              </div>
              <div className="col-lg-7 w3l-right-info">
                <div className="testimonial-content">
                  <div className="testimonial">
                    <div className="testi-des">
                      <div className="peopl align-self">
                        <h4>John wilson</h4>
                        <p className="indentity">Customer</p>
                      </div>
                    </div>
                    <blockquote>
                      <q><i className="fas fa-quote-left me-2" /> Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. Semper at tempufddfel.Lorem ipsum dolor sit, amet consectetur ante ipsum elit.</q>
                    </blockquote>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section className="w3l-blog">
    <div className="blog py-5" id="Newsblog">
      <div className="container py-lg-5 py-md-4 py-2">
        <div className="title-content text-center mb-lg-3 mb-4">
          <h6 className="title-subw3hny mb-1">Our Article</h6>
          <h3 className="title-w3l mb-5">Stay Updated with Our <br />News Feed</h3>
        </div>
        <div className="row justify-content-center">
          <div className="col-lg-4 col-md-6 item">
            <div className="card">
              <div className="card-header p-0 position-relative">
                <a href="#blog" className="zoom d-block">
                  <img className="card-img-bottom d-block" src="assets/images/g3.jpg" alt="Card image cap" />
                </a>
              </div>
              <div className="card-body blog-details">
                <a href="#blog" className="blog-desc">Private Contemporary Home Balancing Openness</a>
                <p>Lorem ipsum viverra feugiat. Pellen tesque libero ut justo.</p>
              </div>
              <div className="card-footer">
                <div className="author align-items-center">
                  <a href="#author" className="post-author">
                    <img src="assets/images/team1.jpg" alt className="img-fluid rounded-circle" />
                  </a>
                  <ul className="blog-meta">
                    <li>
                      <span className="meta-value">by</span><a href="#author"> David Marks</a>
                    </li>
                  </ul>
                  <div className="date">
                    <p>20 Oct, 2021</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 item mt-md-0 mt-5">
            <div className="card">
              <div className="card-header p-0 position-relative">
                <a href="#blog" className="zoom d-block">
                  <img className="card-img-bottom d-block" src="assets/images/g4.jpg" alt="Card image cap" />
                </a>
              </div>
              <div className="card-body blog-details">
                <a href="#blog" className="blog-desc">How Does A Designer Home Look Like</a>
                <p>Lorem ipsum viverra feugiat. Pellen tesque libero ut justo.</p>
              </div>
              <div className="card-footer">
                <div className="author align-items-center">
                  <a href="#author" className="post-author">
                    <img src="assets/images/team2.jpg" alt className="img-fluid rounded-circle" />
                  </a>
                  <ul className="blog-meta">
                    <li>
                      <span className="meta-value">by</span><a href="#author"> Lynda Stone</a>
                    </li>
                  </ul>
                  <div className="date">
                    <p>22 Oct, 2021</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 item mt-lg-0 mt-5">
            <div className="card">
              <div className="card-header p-0 position-relative">
                <a href="#blog" className="zoom d-block">
                  <img className="card-img-bottom d-block" src="assets/images/g2.jpg" alt="Card image cap" />
                </a>
              </div>
              <div className="card-body blog-details">
                <a href="#blog" className="blog-desc">Private Contemporary Home Balancing Openness</a>
                <p>Lorem ipsum viverra feugiat. Pellen tesque libero ut justo.</p>
              </div>
              <div className="card-footer">
                <div className="author align-items-center">
                  <a href="#author" className="post-author">
                    <img src="assets/images/team3.jpg" alt className="img-fluid rounded-circle" />
                  </a>
                  <ul className="blog-meta">
                    <li>
                      <span className="meta-value">by</span><a href="#author"> David Nelson</a>
                    </li>
                  </ul>
                  <div className="date">
                    <p>23 Oct, 2021</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* <footer className="w3l-footer9">
    <section className="footer-inner-main py-5">
      <div className="container py-md-4">
        <div className="right-side">
          <div className="row footer-hny-grids sub-columns">
            <div className="col-lg-3 sub-one-left">
              <h6>About </h6>
              <p className="footer-phny pe-lg-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ute dolor sit.</p>
              <div className="columns-2 mt-4 pt-lg-2">
                <ul className="social">
                  <li><a href="#facebook"><span className="fab fa-facebook-f" /></a>
                  </li>
                  <li><a href="#linkedin"><span className="fab fa-linkedin-in" /></a>
                  </li>
                  <li><a href="#twitter"><span className="fab fa-twitter" /></a>
                  </li>
                  <li><a href="#google"><span className="fab fa-google-plus-g" /></a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Company</h6>
              <ul>
                <li><a href="#why"><i className="fas fa-angle-right" /> Why Us</a>
                </li>
                <li><a href="#licence"><i className="fas fa-angle-right" />Our Agents
                  </a>
                </li>
                <li><a href="#log"><i className="fas fa-angle-right" />Our Offers
                  </a></li>
                <li><a href="#career"><i className="fas fa-angle-right" /> Careers</a></li>
              </ul>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Services</h6>
              <ul>
                <li><a href="#processing"><i className="fas fa-angle-right" /> Buy Properties</a>
                </li>
                <li><a href="#research"><i className="fas fa-angle-right" /> Sell Properties</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Rent Properties</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Property Search</a>
                </li>
              </ul>
            </div>
            <div className="col-lg-2 sub-two-right">
              <h6>Explore</h6>
              <ul>
                <li><a href="#processing"><i className="fas fa-angle-right" /> Homes for Rent</a>
                </li>
                <li><a href="#research"><i className="fas fa-angle-right" /> Apartments for Rent</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Homes for Sale</a>
                </li>
                <li><a href="#metal"><i className="fas fa-angle-right" /> Apartments for Sale</a>
                </li>
              </ul>
            </div>
            <div className="col-lg-3 sub-one-left ps-lg-5">
              <h6>Stay Update!</h6>
              <p className="w3f-para mb-4">Subscribe to our newsletter to receive our weekly feed.</p>
              <div className="w3l-subscribe-content align-self mt-lg-0 mt-5">
                <form action="#" method="post" className="subscribe-wthree">
                  <div className="flex-wrap subscribe-wthree-field">
                    <input className="form-control" type="email" placeholder="Email" name="email" required />
                    <button className="btn btn-style btn-primary" type="submit">Subscribe</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="below-section mt-5 pt-lg-3">
          <div className="copyright-footer">
            <ul className="footer-w3list text-right">
              <li><a href="#url">Privacy Policy</a>
              </li>
              <li><a href="#url">Terms &amp; Conditions</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
    <button onclick="topFunction()" id="movetop" title="Go to top">
      <span className="fas fa-level-up-alt" aria-hidden="true" />
    </button>
  </footer> */}
  </React.Fragment>

    );
}

export default Home;
